<template>
  <section class="hero is-info">
    <div class="hero-body">
      <div class="container">
        <h1 class="title">
          78 forhandlere i hele landet
        </h1>
      </div>
    </div>
  </section>
</template>

<script>
export default {
  name: 'AppHeader',
  methods: {

  }
}
</script>

<style lang="scss" scoped>
  .hero {
    background-color: #009bde;
    border-top: #004059 5rem solid;
    border-bottom: rgba(0, 64, 89, 1) 5rem solid;

    .title {
      font-size: 2.4rem;
      text-align: center;
    }
  }
</style>
